export default function Dashboard() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Bienvenido al panel del usuario</h1>
    </div>
  )
}
